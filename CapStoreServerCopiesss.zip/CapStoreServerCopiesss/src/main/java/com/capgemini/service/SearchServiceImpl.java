package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Customer;
import com.capgemini.model.Merchant;
import com.capgemini.model.Product;

public class SearchServiceImpl implements SearchService  {

	@Override
	public List<Product> searchProducts(String searchString) {
		
		return null;
	}

	@Override
	public List<Merchant> searchMerchant(String searchString) {
		
		return null;
	}

	@Override
	public List<Customer> searchCustomer(String searchString) {
		
		return null;
	}

	
	
	
	
	
	
}

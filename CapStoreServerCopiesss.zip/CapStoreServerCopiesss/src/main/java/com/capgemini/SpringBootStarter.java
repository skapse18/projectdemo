package com.capgemini;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.capgemini.exception.ProductNotFoundException;
import com.capgemini.model.OrderDetails;
import com.capgemini.model.Product;
import com.capgemini.service.PlaceOrderService;

@SpringBootApplication
public class SpringBootStarter {

	public static void main(String[] args) throws ProductNotFoundException {
		
		
	
		SpringApplication.run(SpringBootStarter.class, args);
		
/*ConfigurableApplicationContext context = SpringApplication.run(SpringBootStarter.class, args);
		
		PlaceOrderService service=(PlaceOrderService) context.getBean("service");
		
		service.getCart(2);
		
		OrderDetails order=service.updatingOrder(2);
		List<Product> p=order.getProduct();
		for(Product pr:p)
		{
			System.out.println(pr.getId());
		}*/
	}
}

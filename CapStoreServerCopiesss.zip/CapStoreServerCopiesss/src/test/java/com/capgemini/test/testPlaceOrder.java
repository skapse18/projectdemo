package com.capgemini.test;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.exception.ProductNotFoundException;
import com.capgemini.model.Cart;
import com.capgemini.model.Product;
import com.capgemini.repository.PlaceOrderRepository;
import com.capgemini.service.PlaceOrderImpl;
import com.capgemini.service.PlaceOrderService;

public class testPlaceOrder {

	PlaceOrderService service;
	
	@Mock
	PlaceOrderRepository repository;
	
	@Before
	public void init()
	{
	
		MockitoAnnotations.initMocks(this);
		service=new PlaceOrderImpl(repository);
	}
	
	@Test
	public void testGetCart() throws ProductNotFoundException
	{
		Product product=new Product(1001,null,null,"xperia",null,null,0.0f,null,50,null,0,0.0f,null,null,null,null,null);
		List list= new ArrayList<>();
		list.add(product);
		Cart cart=new Cart(1,null,null,list,50);
		when(repository.getCart(1)).thenReturn(cart);
		int quantity=service.getCart(1);
	
		
	}
	
	@Test(expected=NullPointerException.class)
	public void CartidisNotValid() throws ProductNotFoundException
	{
		service.getCart(2000);
	}
	

}

package com.capgemini.exception;

public class InvalidProductIdException extends Exception {

	public InvalidProductIdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidProductIdException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductIdException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductIdException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}

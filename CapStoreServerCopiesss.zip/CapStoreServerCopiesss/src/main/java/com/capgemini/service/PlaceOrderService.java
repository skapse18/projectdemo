package com.capgemini.service;

import com.capgemini.exception.ProductNotFoundException;
import com.capgemini.model.Cart;
import com.capgemini.model.Customer;
import com.capgemini.model.OrderDetails;

public interface PlaceOrderService {

	public int getCart(int cart_id) throws ProductNotFoundException;
	
	public OrderDetails updatingOrder(int cart_id) throws ProductNotFoundException;
}

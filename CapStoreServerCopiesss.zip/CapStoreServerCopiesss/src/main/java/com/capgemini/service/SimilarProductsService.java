package com.capgemini.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.capgemini.model.Product;

@Service
public class SimilarProductsService implements SimilarProductsInterface {

	@Override
	public ArrayList<Product> SimilarProductsInterface() {

		return null;

	}

}

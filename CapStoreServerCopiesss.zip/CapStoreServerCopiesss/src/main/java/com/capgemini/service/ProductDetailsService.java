package com.capgemini.service;

import com.capgemini.model.Product;

public interface ProductDetailsService {

	public Product getProductDetails();
}

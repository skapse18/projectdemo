package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.exception.ProductNotFoundException;
import com.capgemini.model.Cart;
import com.capgemini.model.Customer;
import com.capgemini.model.Discount;
import com.capgemini.model.OrderDetails;
import com.capgemini.model.Product;
import com.capgemini.repository.PlaceOrderRepository;
import com.capgemini.repository.SaveProductInOrderRepository;

@Service("service")

public class PlaceOrderImpl implements PlaceOrderService {

	@Autowired(required = true)
	PlaceOrderRepository repo;
	
	@Autowired
	SaveProductInOrderRepository repository;
	
	public PlaceOrderImpl(PlaceOrderRepository repo) {
		super();
		this.repo = repo;
	}
	
	@Override
	public int getCart(int cart_id) throws ProductNotFoundException {

		Cart cart =  repo.getCart(cart_id);
		if(cart==null)
		{
			throw new NullPointerException();
		}
			
		int quantity=0;
		List<Product> productList = repo.getProduct(cart_id);
		for(Product product : productList)
		{
			quantity=product.getQuantity();
		}
		return quantity;
	}

	@Override
	@Transactional
	public OrderDetails updatingOrder(int cart_id) throws ProductNotFoundException {
		
		int id;
		float totalAmount=0;
		int countQuantity=0;
		String status;
		
		int customer_id=repo.getCustomer1(cart_id);
		
		Customer customer = new Customer();
		customer.setId(customer_id);
		
		List<Product> listProduct = repo.getProduct(cart_id);
		
		for (Product product : listProduct) {

			int quantity = product.getQuantity();
		
			
			Discount discount=product.getDiscount();
			System.out.println("Before placing Order - ");
			System.out.println("Product Quantity: " + quantity);
			int updatedQuantity = quantity - 1;
			product.setQuantity(updatedQuantity);
			System.out.println("After placing Order - ");
			System.out.println("Product Quantity: " + updatedQuantity);
			System.out.println("");
			
		
			totalAmount = totalAmount+product.getCost();
			System.out.println(totalAmount);
			System.out.println("");
			
			countQuantity++;
			System.out.println(countQuantity);
			repository.save(product);
			
		}	
		
		List<Product> updatedProduct=repo.getProduct(cart_id);
		
		OrderDetails order = new OrderDetails();
		order.setAmount(totalAmount);
		order.setQuantity(countQuantity);
		order.setProduct(updatedProduct);
		order.setCustomer(customer);
		order.setStatus("Pending");
		repo.save(order);
			
		return order;
	}
}
